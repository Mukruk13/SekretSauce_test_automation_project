
URLS = {
    "login": "https://www.saucedemo.com/",
    "product": "https://www.saucedemo.com/inventory.html",
    "cart": "https://www.saucedemo.com/cart.html",
    "checkout_confirmation": "https://www.saucedemo.com/checkout-step-one.html",
    "checkout_overview": "https://www.saucedemo.com/checkout-step-two.html",
    "checkout_complete": "https://www.saucedemo.com/checkout-complete.html"
}