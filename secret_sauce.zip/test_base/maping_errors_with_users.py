import unittest
from selenium.common.exceptions import NoSuchElementException, TimeoutException
from test_base.sekret_sauce_test_base import BaseTest
from pages.login_page import LoginPage

class MapErrorMessages(BaseTest):
    def setUp(self):
        super().setUp()
        self.driver.get(self.config['urls']['login'])
        self.login_page = LoginPage(self.driver)

    def test_map_error_messages(self):
        for user in self.users:
            try:
                self.login_page.login(user['username'], user['password'])
                try:
                    error_message = self.login_page.get_error_message()
                    print(f"Username: {user['username']}, Error Message: {error_message}")
                except TimeoutException:
                    print(f"No error message found for user: {user['username']}. They may have logged in successfully.")
            except Exception as e:
                print(f"Exception encountered for user: {user['username']}: {str(e)}")

if __name__ == "__main__":
    unittest.main()
